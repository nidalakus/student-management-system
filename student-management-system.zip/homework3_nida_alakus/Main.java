import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        StudentMenager manager = new StudentMenager();

        int choice;
        do {
            System.out.println("\n=== Student Management System ===");
            System.out.println("1. Add Student");
            System.out.println("2. Remove Student");
            System.out.println("3. Search Student");
            System.out.println("4. List All Students");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = input.nextInt();
            input.nextLine(); // Clear buffer

            switch (choice) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = input.nextLine();
                    System.out.print("Enter age: ");
                    int age = input.nextInt();
                    input.nextLine();
                    System.out.print("Enter student ID: ");
                    String studentId = input.nextLine();
                    System.out.print("Enter GPA: ");
                    double gpa = input.nextDouble();

                    Student student = new Student(name, age, studentId, gpa);
                    manager.addStudent(student);
                    break;

                case 2:
                    System.out.print("Enter student ID to remove: ");
                    String removeId = input.nextLine();
                    manager.removeStudent(removeId);
                    break;

                case 3:
                    System.out.print("Enter name to search: ");
                    String searchName = input.nextLine();
                    manager.searchStudent(searchName);
                    break;

                case 4:
                    manager.listAllStudents();
                    break;

                case 5:
                    System.out.println("Exiting... Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 5);

        input.close();
    }
}